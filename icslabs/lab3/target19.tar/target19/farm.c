/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_211(unsigned *p)
{
    *p = 3281031192U;
}

unsigned getval_276()
{
    return 1477101431U;
}

unsigned getval_360()
{
    return 2462550344U;
}

void setval_253(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_232()
{
    return 3347660970U;
}

unsigned addval_240(unsigned x)
{
    return x + 113463417U;
}

unsigned addval_351(unsigned x)
{
    return x + 3284633928U;
}

void setval_228(unsigned *p)
{
    *p = 2421742836U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_299()
{
    return 2497743176U;
}

unsigned getval_454()
{
    return 3221803401U;
}

unsigned getval_210()
{
    return 3674260105U;
}

unsigned addval_165(unsigned x)
{
    return x + 3536113289U;
}

void setval_175(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_332()
{
    return 2430634248U;
}

unsigned addval_493(unsigned x)
{
    return x + 3456748456U;
}

void setval_444(unsigned *p)
{
    *p = 2429422032U;
}

unsigned addval_440(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_237()
{
    return 3534016137U;
}

unsigned addval_168(unsigned x)
{
    return x + 2495777269U;
}

unsigned getval_186()
{
    return 3227569801U;
}

void setval_196(unsigned *p)
{
    *p = 3223372425U;
}

unsigned getval_443()
{
    return 3352398297U;
}

unsigned addval_227(unsigned x)
{
    return x + 2425406121U;
}

unsigned addval_281(unsigned x)
{
    return x + 3224948360U;
}

unsigned addval_391(unsigned x)
{
    return x + 3677933961U;
}

unsigned addval_346(unsigned x)
{
    return x + 3529560457U;
}

unsigned getval_442()
{
    return 2425409161U;
}

unsigned addval_333(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_259()
{
    return 3531129481U;
}

unsigned addval_100(unsigned x)
{
    return x + 4089627273U;
}

unsigned getval_412()
{
    return 3263806827U;
}

unsigned addval_289(unsigned x)
{
    return x + 3281047177U;
}

unsigned addval_311(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_128()
{
    return 3223900553U;
}

unsigned getval_248()
{
    return 2425409928U;
}

unsigned getval_451()
{
    return 3286272328U;
}

unsigned getval_380()
{
    return 3251735015U;
}

unsigned getval_394()
{
    return 3375419785U;
}

void setval_244(unsigned *p)
{
    *p = 2495777151U;
}

unsigned addval_452(unsigned x)
{
    return x + 2430634328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
